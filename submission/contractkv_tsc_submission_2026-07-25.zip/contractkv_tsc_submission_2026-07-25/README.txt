ContractKV IEEE Transactions on Services Computing submission

Contents:
- contractkv_tsc.pdf: 12-page manuscript
- contractkv_tsc.tex: self-contained LaTeX source
- contractkv_supplement.pdf: current-vLLM relevance audit
- contractkv_supplement.tex: supplementary source
- figures/: files referenced by the manuscript

Build the manuscript and supplement with two pdflatex passes each. The bibliography is embedded in the manuscript source. Full reproducibility artifacts are available at https://github.com/zhouz4884-coder/contractkv.
