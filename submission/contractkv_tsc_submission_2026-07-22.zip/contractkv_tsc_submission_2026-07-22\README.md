# ContractKV IEEE TSC Submission Package

This package contains the 12-page manuscript PDF, independently compilable
LaTeX source, all referenced figures, and editable/generative figure sources.

## Build

From this directory, run:

```powershell
pdflatex -interaction=nonstopmode -halt-on-error contractkv_tsc.tex
pdflatex -interaction=nonstopmode -halt-on-error contractkv_tsc.tex
```

The bibliography is embedded in `contractkv_tsc.tex`; no external `.bib` file
is required. The paper uses the standard `IEEEtran` document class.

## Contents

- `contractkv_tsc.pdf`: submission-ready 12-page manuscript.
- `contractkv_tsc.tex`: manuscript source.
- `figures/`: exactly the figures referenced by the manuscript.
- `figures/fig1_contractkv_visio.vsdx`: editable Visio source for Fig. 1.
- `source/gen_tsc_figures_v5.py`: generator for Figs. 2--6.
- `source/build_fig1_contractkv_tensor_dataflow.py`: Fig. 1 scene generator.
- `source/fig1_contractkv_visual.scene.json`: editable Fig. 1 scene description.
- `SHA256SUMS.txt`: integrity hashes for all packaged files except itself.

## Artifact

The full reproducibility artifact, frozen manifests, baseline patches, and
machine-readable results are available at:

https://github.com/zhouz4884-coder/contractkv

